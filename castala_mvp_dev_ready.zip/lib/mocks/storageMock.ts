export function getPlaceholderImage(seed: string) {
  return `https://picsum.photos/seed/${encodeURIComponent(seed)}/800/500`;
}
