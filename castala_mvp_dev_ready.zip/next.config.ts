import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  experimental: {},
};

export default nextConfig;
